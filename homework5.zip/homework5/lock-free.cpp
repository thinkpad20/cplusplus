#include "lock_free_stack.h"

int main() {
	return 0;
}
